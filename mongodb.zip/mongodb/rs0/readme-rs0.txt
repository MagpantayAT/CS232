rs0-0 is used to store an intance of mongod use for the replica set rs0
rs0-1 is used to store an intance of mongod use for the replica set rs0
rs0-2 is used to store an intance of mongod use for the replica set rs0


rs0 then will be used as shard server