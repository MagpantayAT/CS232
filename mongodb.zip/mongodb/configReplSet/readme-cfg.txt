cfg0 is used to store an intance of mongod as the first configserver
cfg1 is used to store an intance of mongod as the second configserver
cfg2 is used to store an intance of mongod as the third configserver
