rs1-0 is used to store an intance of mongod use for the replica set rs1
rs1-1 is used to store an intance of mongod use for the replica set rs1
rs1-2 is used to store an intance of mongod use for the replica set rs1


rs1 then will be used as shard server