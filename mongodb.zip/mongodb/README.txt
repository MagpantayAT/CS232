mongodb folder serves as the main folder where the mongod instances will be instantiated


##################################################################################
##																				##				
##									configReplSet								##
##																				##				
##################################################################################

-> 	configReplSet folder holds is a replica sets that holds three mongod instance
	the resides	in the subfolders cfg0, cfg1 and cfg2.  configReplSet is configured
	to be used as the config server

##################################################################################
##																				##				
##									rs0											##
##																				##				
##################################################################################

->	rs0 folder holds is a replica sets that holds three mongod instance the resides
	in the subfolders rs0-0, rs0-1 and rs0-2. rs0 is used as shard.

##################################################################################
##																				##				
##									rs1											##
##																				##				
##################################################################################

->	rs1 folder holds is a replica sets that holds three mongod instance the resides
	in the subfolders rs1-0, rs1-1 and rs1-2. rs1 is used as shard.