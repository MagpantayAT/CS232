<?php include 'navbar-top.php'; ?>

  <section class="content-header">
    <h1>Successful Terrorist Attacks and Targets (S.T.A.T.) Proponents</h1>
    <br>
	</section>

	<section class="content">
      <div class="row">
		    <div class="col-md-1"></div>

      	<div class="col-md-4">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Jay-Arr Buhain</h3>

            <p class="text-center">
              <strong> </strong>
            </p>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
            </div>
            <div class="box-body">
              <img src="dist/img/jr.jpg" width = "100%">
             
            </div>
          </div>
        </div>

        <div class="col-md-2"></div>

        <div class="col-md-4">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Abraham Magpantay</h3>

            <p class="text-center">
              <strong> </strong>
            </p>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
            </div>
            <div class="box-body">
              <img src="dist/img/abe.jpg" width = "100%">
            </div>
          </div>
        
        </div>

		
        <!-- /.col (RIGHT) -->
      </div>
      <!-- /.row -->

    </section>

<?php include 'navbar-bottom.php'; ?>
