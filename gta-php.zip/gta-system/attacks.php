<?php include 'navbar-top.php'; ?>


	

	<section class="content">
      <div class="row">
		
      	<div class="col-md-6">
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Most Used Type of Attack by Terrorist</h3>

            <p class="text-center">
              <strong> </strong>
            </p>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
            </div>
            <div class="box-body">
          <?php
            include '../gta-config/mongo.php';

            // select a database
            $c = $m->selectDB("gtdb")->selectCollection("most_successful_attack_type");
            
            $targets = array(
                          array(
                              '$group' => array("_id" => array("terroristAttackType" => '$_id'),
                                                "mostAttackTypeUsed" => array('$max' => '$value')
                                          )
                            ),
                          array(
                              '$sort' => array("mostAttackTypeUsed" => -1)
                            )
                      );

            $results = $c->aggregate($targets);
            //var_dump($results);
            $max = 0;
            $red = 50;

            foreach ($results as $key => $val) {
              
              for ($i=0; $i < count($val) ; $i++) { 
                $tt = $val[$i]["_id"];
                $mt = $val[$i]["mostAttackTypeUsed"];

                if($max == 0) $max = $mt;
                //echo $tt["terroristAttackType"] . " : " .$mt;
                $percent = $mt/$max*100;
                echo '<div class="progress-group">';
                  echo '<span class="progress-text">'.$tt["terroristAttackType"].'</span>';
                  echo '<span class="progress-number"><b>'.$mt.'</span>';

                  echo '<div class="progress sm">';
                    echo '<div class="progress-bar" style=" background-color: rgb(193, '.$red.', '.$red.'); width: '.$percent.'%"></div>';
                  echo '</div>';
                echo '</div>';
                $red+=2;
              }
            }
            
          ?>
              </div>
            </div>
          </div>


          <div class="col-md-6">
            <?php
              $max = 0;
              $ctr = 1;
              foreach ($results as $key => $val) {
              
              for ($i=0; $i < count($val) ; $i++) {
                if($ctr == 4) break;
                $tt = $val[$i]["_id"];
                $mt = $val[$i]["mostAttackTypeUsed"];

                if($max == 0) $max = $mt;
                //echo $tt["terroristAttackType"] . " : " .$mt;
                $percent = $mt/$max*100;
                
                ?>
                    <!-- Info Boxes Style 2 -->
                    <div class="info-box bg-red">
                      <span class="info-box-icon"><?php echo $ctr; ?></span>

                      <div class="info-box-content">
                        <span class="info-box-text"><?php echo $tt["terroristAttackType"];?></span>
                        <span class="info-box-number"><?php echo $mt; ?></span>

                        <div class="progress">
                          <?php
                            echo '<div class="progress-bar" style="width:'.$percent.'%;"></div>';
                          ?>
                        </div>
                        <span class="progress-description"><?php echo round($percent) . "%"; ?></span>
                      </div>
                      <!-- /.info-box-content -->
                    </div>

                <?php
                $ctr++;
              }
            }
            ?>
          
          </div>

		
        <!-- /.col (RIGHT) -->
      </div>
      <!-- /.row -->

    </section>

<?php include 'navbar-bottom.php'; ?>
